The script imports the following libraries:
  csv
  math
  random
  operator

The code can be executed as: python 15EC10044.py

The dataset, 'iris.csv' should be in the same folder as that of the script

The value of k is iterated from 1 to 5 for the given datset, and it predicts 'Iris-Virginica' for all the values of k.

We get the same results when confirmed with a script which uses scikit-learn libraries.